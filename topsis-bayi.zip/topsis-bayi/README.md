# SPK
Sistem pendukung keputusan dengan metode Topsis &amp; SAW.

 1. Buat database topsis
 2. Import file topsis.sql
 4. Login dengan username: admin, password: admin
