<?php
require_once('includes/init.php');
$judul_page = 'Home';
require_once('template-parts/header.php');




require_once('template-parts/footer.php');
