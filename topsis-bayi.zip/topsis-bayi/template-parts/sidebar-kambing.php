<aside class="sidebar">
	<div class="widget">
		<ul>
			<li><a href="list-desa.php"><span class="fa fa-bars"></span> List Desa</a></li>
			<li><a href="tambah-desa.php"><span class="fa fa-plus"></span> Tambah Desa</a></li>
		</ul>
	</div>
</aside>