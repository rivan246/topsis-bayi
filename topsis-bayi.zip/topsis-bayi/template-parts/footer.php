	
	</div><!-- #main -->
	
	<footer id="footer">
		<div class="container">
			<p>Copyright Desa 2023</a></p>
		</div>
	</footer>

	</div><!-- #page -->
</body>
</html>
<?php
if(isset($pdo)) {
	// Tutup Koneksi
	$pdo = null;
}
?>